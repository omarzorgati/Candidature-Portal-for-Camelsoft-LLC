package com.camelsoft.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
